import React from 'react';
import _ from 'lodash';
import Master from './master/Master'

class App extends React.Component {
	constructor() {
		super();
	}
	
	render() {
		return (
			<Master></Master>
		);
	}
}
export default App;
