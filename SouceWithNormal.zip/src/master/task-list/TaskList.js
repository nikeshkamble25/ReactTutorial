import React from 'react';
import _ from 'lodash';

class TaskList extends React.Component {
	constructor() {
		super();
	}
	bindListView() {
		return _.map(this.props.TaskList, ({ TaskName, Id, IsCompleted }) => {
			return (
				<li key={Id} class='collection-item'>
					{TaskName}
				</li>
			);
		});
	}
	render() {
		return (
			<div className='row'>
				<ul className='collection col-12'>{this.bindListView()}</ul>
			</div>
		);
	}
}
export default TaskList;
