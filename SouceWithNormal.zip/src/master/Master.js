import React from 'react';
import TaskForm from './task-form/TaskForm';
import TaskList from './task-list/TaskList';
import _ from 'lodash';

class App extends React.Component {
	Title = 'Task Manager';
	constructor() {
		super();
		this.state = {
			currentTask:"",
			Tasks: [
				{
					Id: 1,
					TaskName: 'Install NPM',
					IsCompleted: false,
				},
			],
		};
		this.AddTask=this.AddTask.bind(this);
	}

	AddTask(task){
		this.setState({
			Tasks: [
				...this.state.Tasks,
				{
					Id: this.state.Tasks.length + 1,
					TaskName: task,
					IsCompleted: false,
				},
			],
		});
	}

	render() {
		return (
			<div>
				<div className='container'>
					<div className='row'>
						<h4>{this.Title}</h4>
					</div>
					<TaskForm addTask={this.AddTask} currentTask={this.state.currentTask}></TaskForm>
					<TaskList TaskList={this.state.Tasks}></TaskList>
				</div>
			</div>
		);
	}
}
export default App;
